//
//  HotTextViewController.m
//  DispBBS
//
//  Created by Apple on 2015/10/24.
//  Copyright © 2015年 Apple. All rights reserved.
//

#import "HotTextViewController.h"
#import "HotTextCell.h"
#import "AFNetworking.h"
#import "UIImageView+AFNetworking.h"
#import "TextViewController.h"

@interface HotTextViewController ()

@end

@implementation HotTextViewController


-(void)loadHotTexts
{
    // 設定類別屬性 hotTexts 的初始大小為20，用來存抓下來的熱門文章列表
    self.hotTexts = [NSMutableArray arrayWithCapacity:20];
    // 將網址字串轉為 NSURLRequest 物件 request
    NSString *urlString = @"http://disp.cc/api/hot_text.json";
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    // 使用 AFNetworking 的類別 AFHTTPRequestOperation 建立物件 operation
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    // 設定將傳回的資料從 JSON 轉為 NSDictionary
    operation.responseSerializer = [AFJSONResponseSerializer serializer];
    // 設定 operation 執行成功及失敗後要做什麼
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        // 將抓回來的資料存成 NSDictionary 的物件 data
        NSDictionary *data = (NSDictionary *) responseObject;
        // 用 NSLog 顯示錯誤訊息
        NSLog(@"err:%@",data[@"err"]);
        // 將 data 裡的陣列 list 存到 hotTextViewController 的屬性 hotTexts
        self.hotTexts = data[@"list"];
        // 重新顯示 tableView
        [self.tableView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        // opration 執行失敗的話用 UIAlertView 顯示錯誤訊息
        UIAlertView *alertView =[[UIAlertView alloc] initWithTitle:@"Error Retrieving HotTexts"
    message:[error localizedDescription]delegate:nil cancelButtonTitle:@"Ok"                                                  otherButtonTitles:nil];
        [alertView show];
        
    }];
    // 執行 operation
    [operation start];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadHotTexts];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
//#warning Incomplete implementation, return the number of sections
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.hotTexts count];
    return 5;
}




- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
HotTextCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HotTextCell"];
    
//cell.titleLabel.text = [NSString stringWithFormat:@"第 %li 個 Row 的 title", (long)indexPath.row];
//cell.descLabel.text = [NSString stringWithFormat:@"第 %li 個 Row 的 description",(long)indexPath.row];
    NSDictionary *hotText = self.hotTexts[indexPath.row];
    cell.titleLabel.text = hotText[@"title"];
    cell.descLabel.text = hotText[@"desc"];
    //cell.thumbImageView.image = [UIImage imageNamed:@images.png];
    //取出hotText裡的陣列 img_list，可能會有0~3個縮圖
    NSArray *img_list = hotText[@"img_list"];
    if ([img_list count]) { //如果有縮圖的話
        //在網路上的圖還沒載入前，先顯示 displogo
        UIImage *placeholderImage = [UIImage imageNamed:@"images.png"];
        //取得陣列 img_list 裡的第一個縮圖網址，轉為 NSURLRequest
        NSString *imgUrlString = img_list[0];
        NSURL *url = [NSURL URLWithString:imgUrlString];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        //載入網路上的縮圖，並設定到 cell 的 thumbImageView
        __weak HotTextCell *weakCell = cell;
        [cell.thumbImageView setImageWithURLRequest:request
                                   placeholderImage:placeholderImage
                                            success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
                                                weakCell.thumbImageView.image = image;
                                                [weakCell setNeedsLayout];
                                                
                                            } failure:nil
         ];
    } else { //沒有縮圖的話，使用 displogo 當縮圖
        cell.thumbImageView.image = [UIImage imageNamed:@"images.png"];
    }
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    //從屬性 hotTexts 中，利用目前點選第幾個 Row，來取得點選文章的網址
    NSDictionary *hotText = self.hotTexts[self.tableView.indexPathForSelectedRow.row];
    NSString *urlString = [NSString stringWithFormat:@"http://disp.cc/m/%@-%@", hotText[@"bi"], hotText[@"ti"]];
                           //透過 segue 取得目標頁面的 View Controller，將網址存到該類別的屬性
                           TextViewController *textViewController = segue.destinationViewController;
                           textViewController.urlString = urlString;
                           }
@end


