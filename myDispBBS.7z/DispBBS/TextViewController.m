//
//  TextViewController.m
//  DispBBS
//
//  Created by Apple on 2015/10/24.
//  Copyright © 2015年 Apple. All rights reserved.
//

#import "TextViewController.h"
#import "AFNetworking.h"
#import "UIWebView+AFNetworking.h"
#import "AFNetworkActivityIndicatorManager.h"

@interface TextViewController ()

@end

@implementation TextViewController

-(void)viewDidLoad {
    [super viewDidLoad];
    NSURL *url = [NSURL URLWithString:self.urlString];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    
    [self.webView loadRequest:urlRequest progress:nil success:^NSString *(NSHTTPURLResponse *response, NSString *HTML) {
        return HTML;
    } failure:^(NSError *error) {
        NSLog(@"error: %@",[error localizedDescription]);
    }];
    self.webView.delegate = self;
}

-(void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)webViewDidStartLoad:(UIWebView *)webView
{   // web view 中有載入事件時，將 manager 的計數器+1
    [AFNetworkActivityIndicatorManager.sharedManager incrementActivityCount];
}

-(void)webViewDidFinishLoad:(UIWebView *)webView
{   // web view 中的載入事件結束時，將 manager 的計數器-1
    [AFNetworkActivityIndicatorManager.sharedManager decrementActivityCount];
}

-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{   // web view 中的載入事件失敗時，將 manager 的計數器-1
    [AFNetworkActivityIndicatorManager.sharedManager decrementActivityCount];
}/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
