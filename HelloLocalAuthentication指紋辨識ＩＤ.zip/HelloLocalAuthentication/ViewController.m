//
//  ViewController.m
//  HelloLocalAuthentication
//
//  Created by Kent Liu on 2014/11/18.
//  Copyright (c) 2014年 Kent Liu. All rights reserved.
//

#import "ViewController.h"
#import <LocalAuthentication/LocalAuthentication.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)checkButtonPressed:(id)sender {
    
    LAContext *context=[LAContext new];
    
    NSError *error=nil;
    
    if([context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error])
    {
        // OK to use Touch ID
        [context evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics
                localizedReason:@"Check Authentication."
                          reply:
         ^(BOOL success, NSError *error) {
             
             dispatch_async (dispatch_get_main_queue(), ^{
                 
                 [self showResult:success withError:error];
                 
             });
             
         }];
    }
    else
    {
        UIAlertView *alertView=[[UIAlertView alloc] initWithTitle:@"Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alertView show];
        
    }
    
}

- (void) showResult:(BOOL)success withError:(NSError*)error {
    
    if (error) {
        UIAlertView *alertView=[[UIAlertView alloc] initWithTitle:@"Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alertView show];
        return;
    }
    
    if (success) {
        UIAlertView *alertView=[[UIAlertView alloc] initWithTitle:@"Success" message:@"Auth OK." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alertView show];
        
    } else {
        UIAlertView *alertView=[[UIAlertView alloc] initWithTitle:@"Fail" message:@"Auth Fail." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alertView show];
    }
    

    
}


@end
