//
//  AppDelegate.h
//  HelloTheDropbox
//
//  Created by Jenny on 2015/11/25.
//  Copyright © 2015年 PatrickCheng. All rights reserved.
//

#import <UIKit/UIKit.h>

// #step 9 Notification
#define LINKED_OK_NOTIFICATION @"LINKED_OK_NOTIFICATION"


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

