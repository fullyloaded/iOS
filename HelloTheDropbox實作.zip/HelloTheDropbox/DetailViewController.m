//
//  DetailViewController.m
//  HelloTheDropbox
//
//  Created by Jenny on 2015/11/25.
//  Copyright © 2015年 PatrickCheng. All rights reserved.
//

#import "DetailViewController.h"

// step 25 below 5 line
#import <DropboxSDK/DropboxSDK.h>
@interface DetailViewController ()<DBRestClientDelegate>
{
    DBRestClient *restClient;
}


// #step 24
@property (weak, nonatomic) IBOutlet UIImageView *resultImageView;

@end

@implementation DetailViewController

#pragma mark - Managing the detail item

- (void)setDetailItem:(id)newDetailItem {
    if (_detailItem != newDetailItem) {
        _detailItem = newDetailItem;
            
        // Update the view.
        [self configureView];
    }
}

- (void)configureView {
    // Update the user interface for the detail item.
    if (self.detailItem) {
        
        // step 27 below 3 lines
        NSString *sourcePath = [NSString stringWithFormat:@"/%@",_detailItem];
        NSString *tmpPath = [NSTemporaryDirectory() stringByAppendingPathComponent:@"tmp.jpg"];
        [restClient loadFile:sourcePath intoPath:tmpPath];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // step 26 below 3 lines
    DBSession * session = [DBSession sharedSession];
    restClient = [[DBRestClient alloc] initWithSession:session];
    restClient.delegate = self;
    
    [self configureView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// step 28
#pragma mark - DBRestClientDelegate Methods

-(void)restClient:(DBRestClient *)client loadedFile:(NSString *)destPath contentType:(NSString *)contentType metadata:(DBMetadata *)metadata{
    
    //step 29
    NSData * imageData = [[NSData alloc] initWithContentsOfFile:destPath];
    UIImage * image = [[UIImage alloc] initWithData:imageData];
    _resultImageView.image = image;
    
    // step 32
    //尚在背景執行緒執行時,尚完解碼完成即完成下面刪除destPath,故圖片顯示會失敗
//    UIImage *image2 = [[UIImage alloc] initWithContentsOfFile:destPath];
//    _resultImageView.image = image2;
    
    
    
    // step 30
    //Remove the tmp file if it is not used anymore.
    [[NSFileManager defaultManager] removeItemAtPath:destPath error:nil];
    
}


-(void)restClient:(DBRestClient *)client loadFileFailedWithError:(NSError *)error{
    
    // step 31
    NSLog(@"loadFileFailedWithError : %@",error.description);
    
}


@end
