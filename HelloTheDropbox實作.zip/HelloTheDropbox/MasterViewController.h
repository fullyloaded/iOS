//
//  MasterViewController.h
//  HelloTheDropbox
//
//  Created by Jenny on 2015/11/25.
//  Copyright © 2015年 PatrickCheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;

@interface MasterViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;


@end

