//
//  MasterViewController.m
//  HelloTheDropbox
//
//  Created by Jenny on 2015/11/25.
//  Copyright © 2015年 PatrickCheng. All rights reserved.
//

#import "MasterViewController.h"
#import "DetailViewController.h"

// #step 1 below 6 line
#import <DropboxSDK/DropboxSDK.h>

// #step11
#import "AppDelegate.h"

@interface MasterViewController ()<DBRestClientDelegate>
{
    DBSession *dbSession;
    DBRestClient *restClient;
}


@property NSMutableArray *objects;
@end

@implementation MasterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationItem.leftBarButtonItem = self.editButtonItem;

    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(insertNewObject:)];
    self.navigationItem.rightBarButtonItem = addButton;
    self.detailViewController = (DetailViewController *)[[self.splitViewController.viewControllers lastObject] topViewController];
    
    // #step 12 接收notification
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshFileList) name:LINKED_OK_NOTIFICATION object:nil];
}

// #step 3
-(void)viewDidAppear:(BOOL)animated{

    [super viewDidAppear:animated];
    
    if (dbSession == nil) {
        
        [self prepareDBSession];
    }
    
    //必需等viewDidLoad 完成後才能跳到另一個viewController,故這裡用viewDidAppear
}



// #step 2
-(void) prepareDBSession {
    
    dbSession = [[DBSession alloc] initWithAppKey:@"jv802x6axrru1yc" appSecret:@"nz1u0zn5asju06c" root:kDBRootAppFolder];//Root與申請一致
    
    [DBSession setSharedSession:dbSession];  //形成singleterm 物件
    
    if ([dbSession isLinked]) {
        
        //Already Logined
        
        
        // #step 5 接上refreshFileList
        [self refreshFileList];
    }
    else
    {
        
        //Need Login
        [dbSession linkFromController:self];
    }
    
}

// #step 4
-(void) refreshFileList {
    
    // #step 12 test notification
    NSLog(@"refreshFileList executed.");
    
    // # step 13 restClient取得檔案清單
    if (restClient == nil) {
        
        restClient = [[DBRestClient alloc] initWithSession:dbSession];
        restClient.delegate = self;
    }
    
    [restClient loadMetadata:@"/"]; //根目錄
    
}





- (void)viewWillAppear:(BOOL)animated {
    self.clearsSelectionOnViewWillAppear = self.splitViewController.isCollapsed;
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)insertNewObject:(id)sender {
    
    
    // #step 17 上傳檔案
    NSString *fileName = [NSString stringWithFormat:@"%@.png",[[NSDate date] description]];
    
    NSString *localFilePath = [[NSBundle mainBundle] pathForResource:@"cat2.png" ofType:nil];
    
    NSString *targetPath = @"/"; //根目錄,未建子目錄,
    
    [restClient uploadFile:fileName
                    toPath:targetPath
             withParentRev:nil
                  fromPath:localFilePath];



}

#pragma mark - Segues

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"showDetail"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        
        
        // step 22 改為NSString
        NSString *object = self.objects[indexPath.row];
        DetailViewController *controller = (DetailViewController *)[[segue destinationViewController] topViewController];
        [controller setDetailItem:object];
        controller.navigationItem.leftBarButtonItem = self.splitViewController.displayModeButtonItem;
        controller.navigationItem.leftItemsSupplementBackButton = YES;
    }
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.objects.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];

    // step 23 改為NSString
    NSString *object = self.objects[indexPath.row];
    cell.textLabel.text = [object description];
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
      // #step 20
        NSString *filePathName = [NSString stringWithFormat:@"/%@",_objects[indexPath.row]];
        [restClient deletePath:filePathName];
        
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }
}


// #step 14 ,2 Method
#pragma mark - DBRestClientDelegate Methods
-(void) restClient:(DBRestClient *)client loadedMetadata:(DBMetadata *)metadata{
    
    //#step 16
    if (metadata.isDirectory == false) {
        
        return;
    }
    
    if (_objects == nil)
    {
        _objects = [NSMutableArray new];
    }
    else
    {
        [_objects removeAllObjects];
    }
    
    for (DBMetadata * data in metadata.contents)
    {
        NSLog(@"Filename: %@",data.filename);
        [_objects addObject:data.filename];
    }
    
    [self.tableView reloadData];
}

-(void)restClient:(DBRestClient *)client loadMetadataFailedWithError:(NSError *)error{
    
    // #step 15
    NSLog(@"loadMetaDataFailedWithError: %@",error.description);
}

// #step 19 上傳結果 - 上傳成功
-(void)restClient:(DBRestClient *)client uploadedFile:(NSString *)destPath from:(NSString *)srcPath metadata:(DBMetadata *)metadata{
    
    NSLog(@"Upload OK : %@ -> %@(%@)",srcPath,destPath,metadata);
    
    [self refreshFileList];
}


// #step 18 上傳結果 - 上傳失敗通知
-(void)restClient:(DBRestClient *)client uploadFileFailedWithError:(NSError *)error{
    
    NSLog(@"uploadFileFailedWitherror: %@",error.description);
}

// #step 21 刪除 - restClient portocol 通知 下列 2 Method
-(void)restClient:(DBRestClient *)client deletedPath:(NSString *)path{
    
    [self refreshFileList];
}

-(void)restClient:(DBRestClient *)client deletePathFailedWithError:(NSError *)error{
    
    NSLog(@"deletePathFailedWithError : %@",error.description);
}

@end
