//
//  ExtensionDelegate.h
//  AFNetworking watchOS Extension
//
//  Created by Kevin Harwood on 8/3/15.
//  Copyright © 2015 Gowalla. All rights reserved.
//

#import <WatchKit/WatchKit.h>

@interface ExtensionDelegate : NSObject <WKExtensionDelegate>

@end
