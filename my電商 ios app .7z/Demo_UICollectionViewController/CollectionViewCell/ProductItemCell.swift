//
//  ProductItemCell.swift
//  Demo_UICollectionViewController
//
//  Created by Danny&Cabby on 11/14/15.
//  Copyright © 2015 musicabbage. All rights reserved.
//

import UIKit

class ProductItemCell: UICollectionViewCell {

    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var titlelabel: UILabel!
    @IBOutlet weak var shipqty: UILabel!
    @IBOutlet weak var ordermonth: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.backgroundColor = UIColor.whiteColor()
        
    }

}
