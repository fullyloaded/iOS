//
//  CCCollectionViewController.swift
//  Demo_UICollectionViewController
//
//  Created by Danny&Cabby on 11/14/15.
//  Copyright © 2015 musicabbage. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"
private let reuseSupIdentifier = "Headerview"

class CCCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
    
    // internal
    
    // private
    private let _itemSizeRatio: CGFloat = 190.0 / 160.0
    private let _customFlowLayout = FlowLayoutObject()
    
    var datasource: NSArray!
    
    // MARK: - IBAction/control events
    
    // MARK: - life cycle

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Register cell classes/nib
        self.collectionView!.registerNib(UINib(nibName: "ProductItemCell", bundle: nil), forCellWithReuseIdentifier: reuseIdentifier)
        self.collectionView!.registerNib(UINib(nibName: "CompanyListView", bundle: nil), forSupplementaryViewOfKind: UICollectionElementKindSectionHeader, withReuseIdentifier: reuseSupIdentifier)
        
        // Do any additional setup after loading the view.
        
        self.initVariable()
        
        self.initLayout()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - public
    
    // MARK: - private
    
    private func initVariable() {
        
        self.datasource = self.getProductList()
        
    }
    
    private func initLayout() {
      
        self.collectionView?.collectionViewLayout = _customFlowLayout
      
    }
    
    private func getProductList() -> NSArray {
        
        var productList: NSArray!
        
        do {
            
            let sourceUrl = NSBundle.mainBundle().URLForResource("productlist", withExtension: "json")
            
            let jsonData = NSData(contentsOfURL: sourceUrl!)
            
            let jsonArray = try NSJSONSerialization.JSONObjectWithData(jsonData!, options: NSJSONReadingOptions.AllowFragments)
            
            productList = (jsonArray as! NSDictionary).objectForKey("rows") as! NSArray
            
        } catch let error {
            
            print(error)
            
        }
        
        return productList!
        
    }
    
    private func configureCell(cell: ProductItemCell, withIndexPath index: NSIndexPath) {
        
        let productInfo = self.datasource.objectAtIndex(index.row)
        
        cell.titlelabel.text = productInfo.objectForKey("name") as? String
        cell.shipqty.text = productInfo.objectForKey("shipqty") as? String
        cell.ordermonth.text = productInfo.objectForKey("ordmonth") as? String
        
        if let imageUrl = NSURL(string: productInfo.objectForKey("imageurl") as! String) {
            
            cell.imageview.image = nil;
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { () -> Void in
                
                if let data = NSData(contentsOfURL: imageUrl) {
                    
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                        
                        cell.imageview.image = UIImage(data: data)
                        
                    })
                    
                }
                
            })
            
        } else {
            
            cell.imageview.image = nil
            
        }
        
    }
    
    // MARK: - delegate

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: UICollectionViewDataSource
    override func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return self.datasource.count
    }

    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
       
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(reuseIdentifier, forIndexPath: indexPath) as! ProductItemCell
        
        // Configure the cell
        self.configureCell(cell, withIndexPath: indexPath)
    
        return cell
    }
    
    override func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        
        if let productInfo = self.datasource.objectAtIndex(indexPath.row) as? NSDictionary {
            
            let productId = productInfo.objectForKey("id")!
            let productName = productInfo.objectForKey("name")!
            let shipQty = productInfo.objectForKey("shipqty")!
            let orderMonth = productInfo.objectForKey("ordmonth")!
            
            let message = "id: \(productId)\n產品名稱: \(productName)\n出貨數量: \(shipQty)\n下單月份: \(orderMonth)"
            
            let alert = UIAlertController(title: "select index \(indexPath.row)",
                message: message,
                preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "確定", style: UIAlertActionStyle.Cancel, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            
        }
        
    }
    
    override func collectionView(collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, atIndexPath indexPath: NSIndexPath) -> UICollectionReusableView {
        
        let headerview = collectionView.dequeueReusableSupplementaryViewOfKind(UICollectionElementKindSectionHeader, withReuseIdentifier: reuseSupIdentifier, forIndexPath: indexPath) as! CompanyListView
        
        headerview.layoutButtons()        
        
        return headerview
        
    }

    // MARK: UICollectionViewDelegate

    /*
    // Uncomment this method to specify if the specified item should be highlighted during tracking
    override func collectionView(collectionView: UICollectionView, shouldHighlightItemAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment this method to specify if the specified item should be selected
    override func collectionView(collectionView: UICollectionView, shouldSelectItemAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(collectionView: UICollectionView, shouldShowMenuForItemAtIndexPath indexPath: NSIndexPath) -> Bool {
        return false
    }

    override func collectionView(collectionView: UICollectionView, canPerformAction action: Selector, forItemAtIndexPath indexPath: NSIndexPath, withSender sender: AnyObject?) -> Bool {
        return false
    }

    override func collectionView(collectionView: UICollectionView, performAction action: Selector, forItemAtIndexPath indexPath: NSIndexPath, withSender sender: AnyObject?) {
    
    }
    */
    
    // MARK: UICollectionViewDelegateFlowLayout
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        
        let itemWidth = CGRectGetWidth(collectionView.frame) * 0.5 - _customFlowLayout.minimumInteritemSpacing
        let itemHeight = itemWidth * _itemSizeRatio //+ CGFloat(10 * indexPath.row)
        
        return CGSizeMake(itemWidth, itemHeight)
        
    }
    
//    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAtIndex section: Int) -> UIEdgeInsets {
//        
//        
//        return UIEdgeInsetsMake(5, 5, 5, 5)
//    }

}
