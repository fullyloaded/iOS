 //
//  VerticalSeperator.swift
//  Demo_UICollectionViewController
//
//  Created by Danny&Cabby on 11/15/15.
//  Copyright © 2015 musicabbage. All rights reserved.
//

import UIKit

class VerticalSeperator: UICollectionReusableView {
    
    // internal
    
    // private
    
    // MARK: - IBAction/control events
    
    // MARK: - life cycle
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        
        self.initVariable()
        
        self.initLayout()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        super.init(coder: aDecoder)
        
    }
    
    // MARK: - public
    
    // MARK: - private
    private func initVariable() {
        
        
        
    }
    
    private func initLayout() {
        
        self.backgroundColor = UIColor(white: 0.5, alpha: 0.3)
        
    }
    
    // MARK: - delegate
        
}
