//
//  FlowLayoutObject.swift
//  Demo_UICollectionViewController
//
//  Created by Danny&Cabby on 11/15/15.
//  Copyright © 2015 musicabbage. All rights reserved.
//

import UIKit

private let decorationViewKindSeperatorHor = "Horizontal"
private let decorationViewKindSeperatorVer = "Vertical"

class FlowLayoutObject: UICollectionViewFlowLayout {
    
    // internal
    
    // private

    // MARK: - IBAction/control events
    
    // MARK: - life cycle
    override init() {
        
        super.init()
        
        self.initVariable()
        
        self.initLayout()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        super.init(coder: aDecoder)
        
    }
    
    // MARK: - public
    
    // MARK: - private
    private func initVariable() {
        
        
        
    }
    
    private func initLayout() {
        
        self.registerClass(HorizontalSeperator.self, forDecorationViewOfKind: decorationViewKindSeperatorHor)
        self.registerClass(VerticalSeperator.self, forDecorationViewOfKind: decorationViewKindSeperatorVer)
        self.minimumLineSpacing = 2.0
        self.minimumInteritemSpacing = 0.5
        self.headerReferenceSize = CGSizeMake(self.collectionViewContentSize().width, 60.0)
        
    }
    
    // MARK: - override
    
    override func layoutAttributesForDecorationViewOfKind(elementKind: String, atIndexPath indexPath: NSIndexPath) -> UICollectionViewLayoutAttributes? {
        
        //get cell layout attributes
        let cellAttributes = self.layoutAttributesForItemAtIndexPath(indexPath)!
        
        //decoration layout attributes
        let layoutAttributes = UICollectionViewLayoutAttributes(forDecorationViewOfKind: elementKind, withIndexPath: indexPath)
        
        //configure frame
        let cellFrame = cellAttributes.frame
        var layoutFrame = cellAttributes.frame
        if elementKind == decorationViewKindSeperatorHor {
            
            //horizontal seperator
            layoutFrame.origin.y = CGRectGetMaxY(cellFrame)
            layoutFrame.size.height = self.minimumLineSpacing
            layoutFrame.size.width = CGRectGetWidth(cellFrame) + self.minimumInteritemSpacing * 2.0
            
            
        } else if elementKind == decorationViewKindSeperatorVer {
            
            //vertical seperator
            layoutFrame.size.width = self.minimumInteritemSpacing
            layoutFrame.size.height = CGRectGetHeight(cellFrame) + self.minimumLineSpacing
            
            //make it on the top of horizontal seperator
            layoutAttributes.zIndex = 1000
            
        }
        
        layoutAttributes.frame = layoutFrame
        
        return layoutAttributes
        
    }

    
    override func layoutAttributesForElementsInRect(rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        
        var layoutAttributes = super.layoutAttributesForElementsInRect(rect)!
        
        for layoutItem in layoutAttributes {
            
            if layoutItem.representedElementCategory == UICollectionElementCategory.Cell {
                
                let indexPath = layoutItem.indexPath
                
                //add vertical item attributes
                let verticalSeperatorItem = self.layoutAttributesForDecorationViewOfKind(decorationViewKindSeperatorVer, atIndexPath: indexPath)!
                layoutAttributes.append(verticalSeperatorItem)
                
                //add horizontal item attributes
                let horizontalSeperatorItem = self.layoutAttributesForDecorationViewOfKind(decorationViewKindSeperatorHor, atIndexPath: indexPath)!
                layoutAttributes.append(horizontalSeperatorItem)
                
            }
            
        }
        
        return layoutAttributes
        
    }
    
}
