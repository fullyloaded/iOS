//
//  HorizontalSeperator.swift
//  Demo_UICollectionViewController
//
//  Created by Danny&Cabby on 11/15/15.
//  Copyright © 2015 musicabbage. All rights reserved.
//

import UIKit

class HorizontalSeperator: UICollectionReusableView {
    
    // internal
    
    // private

    // MARK: - IBAction/control events
    
    // MARK: - life cycle
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        
        self.initVariable()
        
        self.initLayout()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        super.init(coder: aDecoder)
        
    }
    
    // MARK: - public
    
    // MARK: - private
    private func initVariable() {
        
        
        
    }
    
    private func initLayout() {
        
        self.backgroundColor = UIColor(red: 0.922, green: 0.945, blue: 0.969, alpha: 1.00)
        
    }
    
    // MARK: - delegate
    
    
}
