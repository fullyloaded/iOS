//
//  CompanyListView.swift
//  Demo_UICollectionViewController
//
//  Created by Danny&Cabby on 11/16/15.
//  Copyright © 2015 musicabbage. All rights reserved.
//

import UIKit

class CompanyListView: UICollectionReusableView {

    // internal
    @IBOutlet weak var scrollview: UIScrollView!
    @IBOutlet weak var buttonPanelView: UIView!
    @IBOutlet weak var indicatorView: UIView!
    @IBOutlet weak var constraintIndicatorLeading: NSLayoutConstraint!
    @IBOutlet weak var constraintPanelHeight: NSLayoutConstraint!
    @IBOutlet weak var constraintPanelWidth: NSLayoutConstraint!
    
    var companyList = Array<String>()
    
    // private
    private let indicatorInterval: CGFloat = 5.0

    // MARK: - IBAction/control events
    func buttonClicked(sender: UIButton) {
        
        self.constraintIndicatorLeading.constant = CGRectGetMinX(sender.frame) + self.indicatorInterval
        self.indicatorView.setNeedsUpdateConstraints()
        
        UIView.animateWithDuration(0.3) { () -> Void in
            
            self.indicatorView.layoutIfNeeded()
            
        }
        
    }
    
    // MARK: - life cycle
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.initVariable()
        
        self.initLayout()
        
    }
    
    // MARK: - public
    func layoutButtons() {
        
        for subview in self.buttonPanelView.subviews {
            
            if subview.isKindOfClass(UIButton.self) {
                
                subview.removeFromSuperview()
                
            }
            
        }
        
        var currentX: CGFloat = 0.0
        let buttonWidth: CGFloat = 130.0
        let buttonHeight = CGRectGetHeight(self.frame)
        
        let buttonTitleColor = UIColor(red: 0.467, green: 0.514, blue: 0.553, alpha: 1.00)
        let buttonTitleFont = UIFont.systemFontOfSize(18.0)
        
        for (index, buttonTitle) in EnumerateSequence(self.companyList) {
            
            let button = UIButton(type: UIButtonType.Custom)
            button.tag = index
            button.frame = CGRectMake(currentX, 0.0, buttonWidth, buttonHeight)
            button.setTitle(buttonTitle, forState: UIControlState.Normal)
            button.setTitleColor(buttonTitleColor, forState: UIControlState.Normal)
            button.titleLabel?.font = buttonTitleFont
            button.addTarget(self, action: Selector("buttonClicked:"), forControlEvents: UIControlEvents.TouchUpInside)
            
            self.buttonPanelView.addSubview(button)
            currentX = CGRectGetMaxX(button.frame)
        }
        
        self.constraintPanelWidth.constant = currentX;
        self.constraintPanelHeight.constant = CGRectGetHeight(self.frame)
        
    }
    
    // MARK: - private
    
    private func initVariable() {
        
        self.companyList.append("Company 1")
        self.companyList.append("Company 2")
        self.companyList.append("Company 3")
        self.companyList.append("Company 4")
        self.companyList.append("Company 5")
        self.companyList.append("Company 6")
        self.companyList.append("Company 7")
        
    }
    
    private func initLayout() {
        
    }
    
    
    
    // MARK: - delegate
    
}
