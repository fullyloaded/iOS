//
//  MasterViewController.m
//  HelloAltimeter
//
//  Created by Kent Liu on 2014/11/19.
//  Copyright (c) 2014年 Kent Liu. All rights reserved.
//

#import "MasterViewController.h"
#import "DetailViewController.h"
#import <CoreMotion/CoreMotion.h>

@interface MasterViewController ()
{
    CMAltimeter *altimeter;
}

@property NSMutableArray *objects;
@end

@implementation MasterViewController

- (void)awakeFromNib {
    [super awakeFromNib];
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        self.clearsSelectionOnViewWillAppear = NO;
        self.preferredContentSize = CGSizeMake(320.0, 600.0);
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationItem.leftBarButtonItem = self.editButtonItem;

    UIBarButtonItem *startButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemPlay target:self action:@selector(startStopAltimeter)];
    self.navigationItem.rightBarButtonItem = startButton;
    self.detailViewController = (DetailViewController *)[[self.splitViewController.viewControllers lastObject] topViewController];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) startStopAltimeter {
    
    if([CMAltimeter isRelativeAltitudeAvailable] == NO)
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:@"This device don't support Altimeter." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alertView show];
        
        return;
    }
    
    if(altimeter == nil)
    {
        altimeter = [CMAltimeter new];
    //用 NSOperationQueue 提供個別服務    
        NSOperationQueue *queue = [NSOperationQueue mainQueue];
        
        [altimeter startRelativeAltitudeUpdatesToQueue:queue withHandler:^(CMAltitudeData *altitudeData, NSError *error) {
            
            if(error == nil)
            {
                [self insertNewResult:altitudeData];
            }
            
        }];
        
    }
    else
    {
        [altimeter stopRelativeAltitudeUpdates];
        altimeter = nil;
    }
    
    // Change the Buttons
    
    if (altimeter == nil)
    {
        UIBarButtonItem *startButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemPlay target:self action:@selector(startStopAltimeter)];
        self.navigationItem.rightBarButtonItem = startButton;
    }
    else
    {
        UIBarButtonItem *stopButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemStop target:self action:@selector(startStopAltimeter)];
        self.navigationItem.rightBarButtonItem = stopButton;
    }
    
    
    
}

- (void)insertNewResult:(CMAltitudeData*)result {
    if (!self.objects) {
        self.objects = [NSMutableArray new];
    }

    [self.objects insertObject:result atIndex:0];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - Segues

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"showDetail"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        NSDate *object = self.objects[indexPath.row];
        DetailViewController *controller = (DetailViewController *)[[segue destinationViewController] topViewController];
        [controller setDetailItem:object];
        controller.navigationItem.leftBarButtonItem = self.splitViewController.displayModeButtonItem;
        controller.navigationItem.leftItemsSupplementBackButton = YES;
    }
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.objects.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];

    CMAltitudeData *item = self.objects[indexPath.row];
    
    NSString *text = [NSString stringWithFormat:@"(%.1f) %.3f kpa %+.3f m",item.timestamp,[item.pressure floatValue],[item.relativeAltitude floatValue]];
    
    cell.textLabel.text = [text description];
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.objects removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }
}

@end
