//
//  AppDelegate.h
//  HelloAltimeter
//
//  Created by Kent Liu on 2014/11/19.
//  Copyright (c) 2014年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

