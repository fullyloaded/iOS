//
//  MasterViewController.h
//  HelloBackgroundFetcher
//
//  Created by Kent Liu on 2015/1/8.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;

@interface MasterViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;


@end

