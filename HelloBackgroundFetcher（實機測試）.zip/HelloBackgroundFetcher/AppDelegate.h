//
//  AppDelegate.h
//  HelloBackgroundFetcher
//
//  Created by Kent Liu on 2015/1/8.
//  Copyright (c) 2015年 Kent Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

#define DO_JOB_NOTIFICATION  @"DO_JOB_NOTIFICATION"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

